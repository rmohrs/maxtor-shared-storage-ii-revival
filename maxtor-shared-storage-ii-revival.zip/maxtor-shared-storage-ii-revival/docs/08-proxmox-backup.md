# 8. Backup target for Proxmox VE

The Maxtor works fine as a storage for plain `vzdump` backups. Prerequisite: the share is mounted on the Proxmox host at `/mnt/maxtor` via [`examples/fstab.example`](../examples/fstab.example) (see [guide 7](07-clients.md)).

## 1. Add the storage

```sh
pvesm add dir maxtor-backup --path /mnt/maxtor --content backup --is_mountpoint yes
pvesm status
```

`--is_mountpoint yes` is important: if the share is not mounted, Proxmox marks the storage *inactive* instead of writing the backup to the local disk underneath `/mnt/maxtor`.

## 2. Test backup

Pick a small container (`pct list`):

```sh
vzdump <CT_ID> --storage maxtor-backup --mode snapshot --compress zstd
```

Expected:

```
INFO: creating vzdump archive '/mnt/maxtor/dump/vzdump-lxc-...tar.zst'
INFO: Total bytes written: 1143726080 (1.1GiB, 55MiB/s)
INFO: archive file size: 419MB
INFO: Finished Backup of VM ... (00:00:44)
```

The 55 MiB/s refer to uncompressed data. After zstd compression the Maxtor writes roughly 10 MB/s.

Proxmox shows `filesystem type on dumpdir is 'cifs' - using /var/tmp/... for temporary files` – that is normal.

## 3a. Box always on → scheduled job

*Datacenter → Backup → Add*: storage `maxtor-backup`, selection *All*, mode *Snapshot*, compression *ZSTD*, schedule e.g. `sun 03:00`, tab *Retention*: *Keep Last* = 3.

## 3b. Box only on for backups → script

Many people (us included) only switch the old box on for backups. [`scripts/maxtor-backup.sh`](../scripts/maxtor-backup.sh) does the whole run:

1. checks that the Maxtor answers,
2. shows the RAID status (needs SSH key, see below),
3. triggers the automount and verifies the share is really mounted,
4. backs up all VMs and containers, keeps the last 3 of each,
5. unmounts and asks whether to power the Maxtor off.

Install it on the Proxmox host:

```sh
cp scripts/maxtor-backup.sh /usr/local/bin/maxtor-backup
chmod +x /usr/local/bin/maxtor-backup
# edit MAXTOR=<MAXTOR_IP> at the top
maxtor-backup
```

### SSH key for the Proxmox host (optional)

So the script can read the RAID status and power the box off, give the Proxmox host its own key:

```sh
# on the Proxmox host
ssh-keygen -t rsa -b 2048 -N '' -f /root/.ssh/id_rsa
cat /root/.ssh/id_rsa.pub
```

Append that line to `/root/.ssh/authorized_keys` on the Maxtor (e.g. from a computer that already has key access):

```sh
echo '<PASTE_PUBLIC_KEY>' | ssh maxtor 'cat >> /root/.ssh/authorized_keys'
```

Without it the script still backs up; it just skips the RAID status and you power the box off yourself.

## Powering the box off safely

Never just pull the plug. An unclean shutdown makes the old md driver resync the whole mirror (about 2 hours) and ext3 has to replay its journal.

```sh
umount /mnt/maxtor          # on the Proxmox host first
ssh maxtor poweroff         # or via the web interface / power button
```
